<?php

use yii\helpers\Url;
use yii\helpers\Html;

$this->title = 'Contáctanos | Locosxchiloe';

?>
<div class="main_content">

    <!-- START SECTION CONTACT -->
    <div class="section pb_70">
        <div class="container ">
            <h2 class="text-center">Contáctanos</h2>
            <div class="row">

            <div class="col-md-2"></div>
                <div class="col-md-4">
                    <div class="contact_wrap contact_style3">
                        <div class="contact_icon">
                            <i class="linearicons-envelope-open"></i>
                        </div>
                        <div class="contact_text">
                            <span>Correo Electronico</span>
                            <a href="mailto:ventas@locosxchiloe.cl">ventas@locosxchiloe.cl </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="contact_wrap contact_style3">
                        <div class="contact_icon">
                            <i class="linearicons-tablet2"></i>
                        </div>
                        <div class="contact_text">
                            <span>Telefono</span>
                            <p>+569 5700 1623</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <?= Html::beginForm(Url::toRoute("site/contact"), "POST", ['enctype' => 'multipart/form-data', 'id' => 'cp']) ?>

                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text" name="nombre" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="correo">Correo Electronico</label>
                        <input type="text" name="correo" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="mensaje">Mensaje</label>
                        <textarea class="form-control" name="mensaje" id=""></textarea>
                    </div>
                    <button class="btn btn-fill-out btn-block">Enviar Mensaje</button>
                    <?= Html::endForm() ?>

                </div>
                <div class="col-md-2"></div>

            </div>
        </div>
    </div>
</div>