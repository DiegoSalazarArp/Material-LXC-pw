<?php 
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/favicon.png">
    <title>Pagar</title>
    <!-- ===== Bootstrap CSS ===== -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- ===== Plugin CSS ===== -->
    <!-- ===== Animation CSS ===== -->
    <link href="assets/css/animate.css" rel="stylesheet">
    <!-- ===== Custom CSS ===== -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/login.css" rel="stylesheet">

    <!-- ===== Color CSS ===== -->
    <link href="assets/css/colors/default.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body style="background-image: url('assets/images/blanco.jpg');" class="mini-sidebar">
<div class="row">
<div class="col-md-2"></div>

    <div class="col-md-8 text-center">
    <h4>Usted será redirigido a realizar el pago, por favor haga click en CONTINUAR</h4>
    <img class="logo" style="margin-left: 0px;" src="assets/images/Logo_locosxchiloe_redondo.png" alt="iniciar sesión" srcset="">
   
</div>
    <div class="col-md-2"></div>

</div>   
<div  class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">

    <form action="<?= $formAction?>" method="POST" role="form">
    <input type="hidden" name="_csrf" value="<?=Yii::$app->request->getCsrfToken()?>" />
<input type="hidden" name="token_ws" value="<?= $token ?>"> 
<button type="submit" class="btn btn-primary btn-block">CONTINUAR</button>
</form>
    </div>

                    
  
    
    </div>
    <div class="col-md-4"></div>

    </div>
    <?php $this->registerJsFile('@web/js/jquery.slimscroll.js',['depends' => [\yii\web\JqueryAsset::className()]]); ?>
        <!-- ===== Wave Effects JavaScript ===== -->
        <?php $this->registerJsFile('@web/js/bootstrap.min.js',['depends' => [\yii\web\JqueryAsset::className()]]); ?>
        <?php $this->registerJsFile('@web/js/waves.js',['depends' => [\yii\web\JqueryAsset::className()]]); ?>
        <!-- ===== Menu Plugin JavaScript ===== -->

        <?php $this->registerJsFile('@web/js/sidebarmenu.js',['depends' => [\yii\web\JqueryAsset::className()]]); ?>
        <!-- ===== Custom JavaScript ===== -->
        <?php $this->registerJsFile('@web/js/custom.js',['depends' => [\yii\web\JqueryAsset::className()]]); ?>
        <!-- ===== Plugin JS ===== -->
        <!-- ===== Style Switcher JS ===== -->
       
        <?php $this->registerJsFile('@web/js/style.switcher.js',['depends' => [\yii\web\JqueryAsset::className()]]); ?>
   
</body>

</html>


