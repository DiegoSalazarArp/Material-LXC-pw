<?php
$this->title = 'Quienes Somos | Locosxchiloe';
$url = "";
if (isset($_SERVER['HTTPS'])) {
    $url = "https://" . $_SERVER['SERVER_NAME']."/";
} else {
    $url = "http://" . $_SERVER['SERVER_NAME']."/";
}
?>
<div class="main_content">

    <!-- STAT SECTION ABOUT -->
    <div class="section">
        <div class="container">
            <div class="row align-items-center">

                <div class="col-lg-8">
                    <div class="heading_s1 text-center">
                        <h2>Quiénes Somos</h2>
                    </div>
                    <p class="quienes-somos" >Somos una empresa que nació a raíz de un emprendimiento en noviembre del año 2017, nuestro objetivo es poder proveer un mercado gourmet con una gran variedad de pescados, marisco e incluso cárnicos, quesos y hortalizas, importados de la Gran Isla de Chiloé y otras regiones del país, a las familias de Santiago y sus comunas, llevándolo a la puerta de manera fácil a las puertas de tu hogar.
                    </p>
                    <p class="quienes-somos" >Tenemos un compromiso con el medioambiente y nuestros organismos, además buscamos constantemente una magnífica experiencia de sabores y aseguramos la mejor calidad y responsabilidad para toda nuestra comunidad.
                        Esperamos muy pronto construir nuestra propia casa e invitarlos a degustar con nosotros los mejores sabores de La gran Isla de Chiloé.
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="about_img scene mb-4 mb-lg-0">
                        <img class="img img-responsive" src="<?= $url ?>assets/images/Logo_redondo.png" alt="Locosxchiloe" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>